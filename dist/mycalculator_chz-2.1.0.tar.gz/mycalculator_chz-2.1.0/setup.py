from setuptools import setup, find_packages

setup(
    name='mycalculator_chz',
    version='2.1.0',
    packages=find_packages(),
    author='Camila Haika Zumach',
    author_email='haika2407@gmail.com',
    description='A package of simple math functions',
    platforms=["win_amd64", "linux_x86_64", "macosx_10_9_x86_64"],
    python_requires='>=3.6',
)
