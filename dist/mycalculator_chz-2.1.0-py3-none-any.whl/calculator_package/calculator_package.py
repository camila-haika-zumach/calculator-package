from typing import Union


class Calculator:
    def __init__(self) -> None:
        self.memory: Union[int, float] = 0

    def add(self,
            num1: Union[int, float],
            num2: Union[int, float]) -> None:
        self.memory = num1 + num2

    def subtract(self,
                 num1: Union[int, float],
                 num2: Union[int, float]) -> None:
        self.memory = num1 - num2

    def multiply(self,
                 num1: Union[int, float],
                 num2: Union[int, float]) -> None:
        self.memory = num1 * num2

    def divide(self,
               num1: Union[int, float],
               num2: Union[int, float]) -> None:
        if num2 == 0:
            raise ValueError("Cannot divide by zero")
        self.memory = num1 / num2

    def nth_root(self, num: Union[int, float], n: int) -> None:
        if num < 0 and n % 2 == 0:
            raise ValueError("Cannot calculate even root of a negative number")
        self.memory = num ** (1 / n)

    def reset_memory(self) -> None:
        self.memory = 0

    def get_memory(self) -> Union[int, float]:
        return self.memory